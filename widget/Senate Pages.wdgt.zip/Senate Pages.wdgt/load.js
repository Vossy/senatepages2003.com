xmlHttp = new XMLHttpRequest();

function loadPosts()
{
   xmlHttp.onreadystatechange = displayPosts;
   xmlHttp.open("get", "http://www.senatepages2003.com/widget/check-posts.php", true);
   xmlHttp.send(null);
}

function displayPosts()
{
   if(xmlHttp.readyState != 4)
      return;

   // alert("readyState == " + xmlHttp.readyState);

   htmlList = document.getElementById("PostList");
   htmlList.innerHTML = "";

   postList = xmlHttp.responseXML.getElementsByTagName("post");

   // document.getElementById("PostCount").innerHTML = postList.length + " Latest Posts";

   for(i = 0; i < 5; i++)
   {
      // if(i == 0 && widget)
      //    widget.setPreferenceForKey(postList[i].getAttribute("id"), "lastPost")

      author = postList[i].getAttribute("author");
      if(postList[i].getAttribute("title") != "")
         title = postList[i].getAttribute("title");
      else
         title = "[No Title]";

      // do this the offical DOM style...
      /* postItem = document.createElement("li");
      authorEl = document.create("Element");
      authorEl.appendChild(document.createTextNode(author));
      postItem.appendChild(authorEl);
      postItem.appendChild(document.createTextNode(" " + title); */

      htmlList.innerHTML += "<li class=\"post\"><strong>" + author +  "</strong> " + title  + "</li>";
   };
};

widget.onshow = loadPosts;

